#include "ControlBala.h"

#include <algorithm>//Para removeif

#include "Constantes.h"
#include "Bala.h"//Como controlador de bala necesita la clase bala

//Controla el tiempo de recarga del disparo
void ControlBala::TiempoCargaDisparo(){
    if(!disparoHabilitado) {
        contadorDeRecarga++;
        if(contadorDeRecarga >= tiempoDeRecarga){
            disparoHabilitado = true;
            contadorDeRecarga = 0;  // 
        }
    }
}

//Crea dos balas en las posiciones iniciales
void ControlBala::disparar(float _x, float _y) {
    balas.emplace_back(_x,_y);
    balas.emplace_back(_x+7,_y);
}

//Actualiza la posicion de todas las balas y limpia las que salen de la pantalla
void ControlBala::actualizar() {
    for(Bala& b : balas){
        b.dibujarBala();
        b.movimientoBala();
    }
}
void ControlBala::limpiarBalasInactivas() {
    balas.erase(
        std::remove_if(balas.begin(), balas.end(),
            [](Bala& b) {
                if (!b.getActiva() || b.getY() <= Limite_vertical_superior) {
                    b.limpiarUltimaPosicion();
                    return true;
                }
                return false;
            }),
        balas.end()
    );
}
